#define VERSION		44
#define REVISION	1
#define DATE		"30.10.1999"
#define VERS		"aiff.datatype 44.1"
#define VSTRING		"aiff.datatype 44.1 (30.10.1999)\r\n"
#define VERSTAG		"\0$VER: aiff.datatype 44.1 (30.10.1999)"
