#define	VERSION		44
#define	REVISION	16
#define	DATE	"10.5.99"
#define	VERS	"cdxl 44.16"
#define	VSTRING	"cdxl 44.16 (10.5.99)\r\n"
#define	VERSTAG	"\0$VER: cdxl 44.16 (10.5.99)"
