#define	VERSION		38
#define	REVISION	3
#define	DATE	"3.3.92"
#define	VERS	"dansk.language 38.3"
#define	VSTRING	"dansk.language 38.3 (3.3.92)\n\r"
#define	VERSTAG	"\0$VER: dansk.language 38.3 (3.3.92)"
