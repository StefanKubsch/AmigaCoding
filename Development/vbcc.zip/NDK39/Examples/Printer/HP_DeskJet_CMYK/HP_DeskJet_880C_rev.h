#define VERSION		44
#define REVISION	1
#define DATE		"30.10.1999"
#define VERS		"HP_DeskJet_880C 44.1"
#define VSTRING		"HP_DeskJet_880C 44.1 (30.10.1999)\r\n"
#define VERSTAG		"\0$VER: HP_DeskJet_880C 44.1 (30.10.1999)"
