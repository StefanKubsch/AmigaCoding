/*
 * COPYRIGHT:
 *
 *   Unless otherwise noted, all files are Copyright (c) 1999 Amiga, Inc.
 *   All rights reserved.
 *
 * DISCLAIMER:
 *
 *   This software is provided "as is". No representations or warranties
 *   are made with respect to the accuracy, reliability, performance,
 *   currentness, or operation of this software, and all use is at your
 *   own risk. Neither Amiga nor the authors assume any responsibility
 *   or liability whatsoever with respect to your use of this software.
 */

#define CONFIG_BW_DPI {75,100,150,300,600,600,600}
#define CONFIG_COLOR_DPI {75,100,150,300,300,300,300}
#define CONFIG_CAN_COMPRESS 1
#define CONFIG_SUPPORTS_COLOR 1
#define CONFIG_COLOR_BW_SAME_RESOLUTION 0
