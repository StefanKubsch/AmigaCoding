#define	VERSION		44
#define	REVISION	14
#define	DATE	"29.9.99"
#define	VERS	"HP_DeskJet_CMYK 44.14"
#define	VSTRING	"HP_DeskJet_CMYK 44.14 (29.9.99)\r\n"
#define	VERSTAG	"\0$VER: HP_DeskJet_CMYK 44.14 (29.9.99)"
