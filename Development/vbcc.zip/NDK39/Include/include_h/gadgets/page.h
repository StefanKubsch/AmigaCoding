#ifndef GADGETS_PAGE_H
#define GADGETS_PAGE_H
/*
**	$VER: page.h 45.1 (21.12.2001)
**	Includes Release 45.1
**
**	Page gadget definitions
**
**	Page gadget is part of layout.gadget
**
**	(C) Copyright 1987-2001 Amiga, Inc.
**	    All Rights Reserved
*/

/*****************************************************************************/

#ifndef GADGETS_LAYOUT_H
#include <gadgets/layout.h>
#endif

#endif /* GADGETS_PAGE_H */
