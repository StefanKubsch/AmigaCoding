#ifndef PRAGMA_VIRTUAL_H
#define PRAGMA_VIRTUAL_H

/*
**	$VER: virtual_lib.h 45.1 (17.12.2001)
**	Includes Release 45.1
**
**	Aztec `C' style pragma header file wrapper
**
**	(C) Copyright 2001 Amiga, Inc.
**	    All Rights Reserved
*/

#ifndef PRAGMAS_VIRTUAL_PRAGMAS_H
#include <pragmas/virtual_pragmas.h>
#endif

#endif /* PRAGMA_VIRTUAL_H */
