#ifndef PRAGMA_INTUITION_H
#define PRAGMA_INTUITION_H

/*
**	$VER: intuition_lib.h 44.1 (1.11.1999)
**	Includes Release 45.1
**
**	Aztec `C' style pragma header file wrapper
**
**	(C) Copyright 2001 Amiga, Inc.
**	    All Rights Reserved
*/

#ifndef PRAGMAS_INTUITION_PRAGMAS_H
#include <pragmas/intuition_pragmas.h>
#endif

#endif /* PRAGMA_INTUITION_H */
