#ifndef PRAGMA_MATHTRANS_H
#define PRAGMA_MATHTRANS_H

/*
**	$VER: mathtrans_lib.h 44.1 (1.11.1999)
**	Includes Release 45.1
**
**	Aztec `C' style pragma header file wrapper
**
**	(C) Copyright 2001 Amiga, Inc.
**	    All Rights Reserved
*/

#ifndef PRAGMAS_MATHTRANS_PRAGMAS_H
#include <pragmas/mathtrans_pragmas.h>
#endif

#endif /* PRAGMA_MATHTRANS_H */
