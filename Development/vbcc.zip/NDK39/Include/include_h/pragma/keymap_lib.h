#ifndef PRAGMA_KEYMAP_H
#define PRAGMA_KEYMAP_H

/*
**	$VER: keymap_lib.h 44.1 (1.11.1999)
**	Includes Release 45.1
**
**	Aztec `C' style pragma header file wrapper
**
**	(C) Copyright 2001 Amiga, Inc.
**	    All Rights Reserved
*/

#ifndef PRAGMAS_KEYMAP_PRAGMAS_H
#include <pragmas/keymap_pragmas.h>
#endif

#endif /* PRAGMA_KEYMAP_H */
