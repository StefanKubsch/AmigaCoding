#ifndef PRAGMA_COMMODITIES_H
#define PRAGMA_COMMODITIES_H

/*
**	$VER: commodities_lib.h 44.1 (1.11.1999)
**	Includes Release 45.1
**
**	Aztec `C' style pragma header file wrapper
**
**	(C) Copyright 2001 Amiga, Inc.
**	    All Rights Reserved
*/

#ifndef PRAGMAS_COMMODITIES_PRAGMAS_H
#include <pragmas/commodities_pragmas.h>
#endif

#endif /* PRAGMA_COMMODITIES_H */
