#ifndef PRAGMA_MATHIEEESINGTRANS_H
#define PRAGMA_MATHIEEESINGTRANS_H

/*
**	$VER: mathieeesingtrans_lib.h 44.1 (1.11.1999)
**	Includes Release 45.1
**
**	Aztec `C' style pragma header file wrapper
**
**	(C) Copyright 2001 Amiga, Inc.
**	    All Rights Reserved
*/

#ifndef PRAGMAS_MATHIEEESINGTRANS_PRAGMAS_H
#include <pragmas/mathieeesingtrans_pragmas.h>
#endif

#endif /* PRAGMA_MATHIEEESINGTRANS_H */
