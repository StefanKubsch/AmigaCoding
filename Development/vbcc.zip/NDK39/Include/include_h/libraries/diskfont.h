#ifndef	LIBRARIES_DISKFONT_H
#define	LIBRARIES_DISKFONT_H
/*
**	$VER: diskfont.h 36.6 (26.11.1990)
**	Includes Release 45.1
**
**	diskfont library definitions
**
**	(C) Copyright 1985-2001 Amiga, Inc.
**	    All Rights Reserved
*/

#ifndef	DISKFONT_DISKFONT_H
#include <diskfont/diskfont.h>
#endif

#endif	/* LIBRARIES_DISKFONT_H */
