#ifndef LIBRARIES_FILEHANDLER_H
#define LIBRARIES_FILEHANDLER_H
/*
**	$VER: filehandler.h 36.2 (12.7.1990)
**	Includes Release 45.1
**
**	device and file handler specific code for AmigaDOS
**
**	(C) Copyright 1986-2001 Amiga, Inc.
**	    All Rights Reserved
*/

#ifndef DOS_FILEHANDLER_H
#include <dos/filehandler.h>
#endif

#endif /* LIBRARIES_FILEHANDLER_H */
